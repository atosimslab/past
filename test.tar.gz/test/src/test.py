#!/usr/bin/env python

# Program: .py

# Programmer: Aamir Alaud Din

# Objective(s):
#

#%%%%%%%%%%%%%%%%%%%%%%%%%
# History of modification:
#%%%%%%%%%%%%%%%%%%%%%%%%%

# S. No.    Date          Description
# ------    ----------    -----------
#     1.    .2016    Original code 

#%%%%%%%%%%%
# Module(s):
#%%%%%%%%%%%

# S. No.    Module(s)                   Description
# ------    ------------------------    -----------


#%%%%%%%%
# Script:
#%%%%%%%%

# Parameter(s):
#%%%%%%%%%%%%%%

# S. No.    Parameter(s)                Description
# ------    ------------------------    -----------


# Input variable(s):
#%%%%%%%%%%%%%%%%%%%

# S. No.    Variable(s)                 Description
# ------    ------------------------    -----------


# Intermediate variable(s):
#%%%%%%%%%%%%%%%%%%%%%%%%%%

# S. No.    Variable(s)                 Description
# ------    ------------------------    -----------


# Output variable(s):
#%%%%%%%%%%%%%%%%%%%%

# S. No.    Variable(s)                 Description
# ------    ------------------------    -----------

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a = 1
print a
